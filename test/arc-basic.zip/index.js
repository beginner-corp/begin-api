exports.handler = async function http (req) {
  return { hello: 'world', one: 1, two: true }
}
